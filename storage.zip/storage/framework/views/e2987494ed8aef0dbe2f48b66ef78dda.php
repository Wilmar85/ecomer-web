<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['product']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-200 transform hover:scale-105 flex flex-col justify-between min-h-[340px]">
    <?php if($product->images->isNotEmpty()): ?>
        <?php
            $imgUrl = method_exists($product->images->first(), 'getImageUrlAttribute') ? $product->images->first()->image_url : (property_exists($product->images->first(), 'image_path') ? asset('storage/' . $product->images->first()->image_path) : asset('storage/' . $product->images->first()->path));
        ?>
        <a href="<?php echo e(route('products.show', $product)); ?>">
            <img src="<?php echo e($imgUrl); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-48 object-cover">
        </a>
    <?php endif; ?>
    <div class="p-4 flex flex-col flex-1 justify-between">
        <div>
            <a href="<?php echo e(route('products.show', $product)); ?>" class="block font-semibold text-gray-900 hover:text-blue-600 mb-2 truncate text-lg"><?php echo e($product->name); ?></a>
            <p class="text-gray-600 text-sm mb-2 line-clamp-2"><?php echo e(Str::limit($product->description, 100)); ?></p>
        </div>
        <div class="flex items-center justify-between pt-2 mb-2">
            <span class="text-xl font-bold text-gray-900">$<?php echo e(number_format($product->price, 2)); ?></span>
        </div>
        <div class="flex gap-1 justify-center">
            <a href="<?php echo e(route('products.show', $product)); ?>"
                class="w-10 h-10 flex justify-center items-center text-center bg-blue-600 border border-transparent rounded-full text-white hover:bg-blue-700 focus:bg-blue-700 active:bg-blue-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0zm6 0c0 5-7 9-7 9s-7-4-7-9a7 7 0 0114 0z" />
                </svg>
            </a>
            <?php if(auth()->guard()->check()): ?>
                <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="w-10 h-10" x-data="{}" @submit.prevent="
                    let form = $el;
                    let data = new FormData(form);
                    fetch(form.action, {
                        method: 'POST',
                        headers: { 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-TOKEN': data.get('_token') },
                        body: data
                    }).then(res => {
                        if(res.redirected) { window.location.href = res.url; return; }
                        if(res.ok) {
                            res.clone().json().then(data => {
                                if(typeof data.count !== 'undefined') {
                                    window.dispatchEvent(new CustomEvent('cart-updated', { detail: { count: data.count } }));
                                    if(window.Laravel && window.Laravel.updateCartCount) window.Laravel.updateCartCount(data.count);
                                } else {
                                    window.dispatchEvent(new CustomEvent('cart-updated'));
                                }
                            });
                        }
                        return res.json();
                    }).catch(() => {});
                ">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                    <input type="hidden" name="quantity" value="1">
                    <button type="submit" class="w-10 h-10 flex justify-center items-center text-center bg-green-600 border border-transparent rounded-full text-white hover:bg-green-700 focus:bg-green-700 active:bg-green-900 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition ease-in-out duration-150">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13l-1.35 2.7A2 2 0 007.48 19h8.94a2 2 0 001.83-1.23L21 13M7 13V6a1 1 0 011-1h9a1 1 0 011 1v7" />
                        </svg>
                    </button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="w-10 h-10 flex justify-center items-center text-center bg-green-600 border border-transparent rounded-full text-white hover:bg-green-700 focus:bg-green-700 active:bg-green-900 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition ease-in-out duration-150">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13l-1.35 2.7A2 2 0 007.48 19h8.94a2 2 0 001.83-1.23L21 13M7 13V6a1 1 0 011-1h9a1 1 0 011 1v7" />
                    </svg>
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH F:\xampp\htdocs\laravel\ecomer-web\resources\views/components/product-card.blade.php ENDPATH**/ ?>