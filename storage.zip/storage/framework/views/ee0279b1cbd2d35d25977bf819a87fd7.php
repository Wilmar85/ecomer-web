
<title><?php echo e($metaTitle ?? config('app.name', 'E-commerce Web')); ?></title>
<meta name="description" content="<?php echo e($metaDescription ?? 'Tienda online de productos de calidad al mejor precio. ¡Descubre nuestras ofertas!'); ?>">
<meta name="keywords" content="<?php echo e($metaKeywords ?? 'ecommerce, tienda, compras, ofertas, productos, categorías'); ?>">
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?php echo e($canonical ?? url()->current()); ?>">

<!-- Open Graph / Facebook -->
<meta property="og:title" content="<?php echo e($ogTitle ?? $metaTitle ?? config('app.name', 'E-commerce Web')); ?>">
<meta property="og:description" content="<?php echo e($ogDescription ?? $metaDescription ?? ''); ?>">
<meta property="og:image" content="<?php echo e($ogImage ?? asset('images/default-og.png')); ?>">
<meta property="og:url" content="<?php echo e($canonical ?? url()->current()); ?>">
<meta property="og:type" content="website">

<!-- Twitter -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo e($twitterTitle ?? $metaTitle ?? config('app.name', 'E-commerce Web')); ?>">
<meta name="twitter:description" content="<?php echo e($twitterDescription ?? $metaDescription ?? ''); ?>">
<meta name="twitter:image" content="<?php echo e($twitterImage ?? asset('images/default-og.png')); ?>">


<?php if(config('seo.google_verification')): ?>
    <meta name="google-site-verification" content="<?php echo e(config('seo.google_verification')); ?>" />
<?php endif; ?>


<?php echo $__env->yieldPushContent('jsonld'); ?>
<?php /**PATH F:\xampp\htdocs\laravel\ecomer-web\resources\views/layouts/partials/seo.blade.php ENDPATH**/ ?>