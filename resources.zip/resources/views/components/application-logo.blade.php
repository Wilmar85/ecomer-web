<img src="{{ asset('images/logo.png') }}" alt="Logo" {{ $attributes }}>

