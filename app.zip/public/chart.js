/*! Chart.js v4.4.1 */
// Chart.js CDN build for dashboard charts
// https://cdn.jsdelivr.net/npm/chart.js
