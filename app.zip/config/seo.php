<?php
return [
    // Google Search Console verification code (solo el valor, no la etiqueta completa)
    'google_verification' => env('GOOGLE_SITE_VERIFICATION', null),
];
