<?php
    $metaTitle = $product->name . ' | E-commerce Web';
    $metaDescription = $product->short_description ?? Str::limit(strip_tags($product->description), 150);
    $metaKeywords = $product->name . ', ' . ($product->category->name ?? '') . ', comprar, ecommerce';
    $ogTitle = $product->name;
    $ogDescription = $product->short_description ?? Str::limit(strip_tags($product->description), 150);
    $ogImage = $product->images->isNotEmpty() ? asset('storage/' . $product->images->first()->path) : asset('images/default-og.png');
    $canonical = url()->current();
?>

<?php $__env->startPush('jsonld'); ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "<?php echo e($product->name); ?>",
  "image": [
    <?php if($product->images->isNotEmpty()): ?>
      <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>"<?php echo e(asset('storage/' . $img->path)); ?>"<?php if(!$loop->last): ?>,<?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
      "<?php echo e(asset('images/default-og.png')); ?>"
    <?php endif; ?>
  ],
  "description": "<?php echo e($product->short_description ?? Str::limit(strip_tags($product->description), 150)); ?>",
  "sku": "<?php echo e($product->sku ?? $product->id); ?>",
  "brand": {
    "@type": "Brand",
    "name": "<?php echo e($product->brand->name ?? 'Marca genérica'); ?>"
  },
  "offers": {
    "@type": "Offer",
    "priceCurrency": "MXN",
    "price": "<?php echo e($product->price); ?>",
    "availability": "https://schema.org/<?php echo e($product->stock > 0 ? 'InStock' : 'OutOfStock'); ?>"
  }
}
</script>
<?php $__env->stopPush(); ?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            fetch("<?php echo e(route('preferences.visited', ['productId' => $product->id])); ?>", {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    'Accept': 'application/json'
                }
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e($product->name); ?>

            </h2>
            <div class="flex gap-2 items-center">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $product)): ?>
                    <a href="<?php echo e(route('admin.products.edit', $product)); ?>" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Editar</a>
                <?php endif; ?>
                <a href="<?php echo e(route('products.index')); ?>" class="text-blue-500 hover:text-blue-700">
                    <?php echo e(__('Volver a Productos')); ?>

                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <?php if(session('success')): ?>
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4"
                            role="alert">
                            <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4"
                            role="alert">
                            <span class="block sm:inline"><?php echo e(session('error')); ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div class="space-y-4">
                            <?php if($product->images->isNotEmpty()): ?>
    <div x-data="{ selectedImage: '<?php echo e(method_exists($product->images->first(), 'getImageUrlAttribute') ? $product->images->first()->image_url : asset('storage/' . $product->images->first()->image_path)); ?>' }">
        <div class="relative h-96 overflow-hidden rounded-lg">
            <img :src="selectedImage" alt="<?php echo e($product->name); ?>" class="w-full h-full object-cover transition-all duration-200">
        </div>
        <?php if($product->images->count() > 1): ?>
            <div class="grid grid-cols-4 gap-2 mt-2">
                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $imgUrl = method_exists($image, 'getImageUrlAttribute') ? $image->image_url : asset('storage/' . $image->image_path);
                    ?>
                    <img src="<?php echo e($imgUrl); ?>" alt="<?php echo e($product->name); ?>"
                        class="w-full h-24 object-cover rounded cursor-pointer hover:opacity-75 border-2 border-transparent hover:border-blue-400"
                        @click="selectedImage = '<?php echo e($imgUrl); ?>'">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
                            <?php else: ?>
                                <div class="h-96 bg-gray-200 flex items-center justify-center rounded-lg">
                                    <span class="text-gray-500">Sin imagen</span>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="space-y-6">
                            <div>
                                <h1 class="text-3xl font-bold text-gray-900"><?php echo e($product->name); ?></h1>
                                <p class="text-sm text-gray-500">Categoría: <?php echo e($product->category->name); ?></p>
                            </div>

                            <div class="text-2xl font-bold text-gray-900">
                                $<?php echo e(number_format($product->price, 2)); ?>

                            </div>

                            <div class="prose max-w-none">
                                <?php echo e($product->description); ?>

                            </div>

                            <div class="text-sm text-gray-600">
                                Stock disponible: <?php echo e($product->stock); ?>

                            </div>

                            <?php if(auth()->guard()->check()): ?>
                                <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="space-y-4">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">

                                    <div>
                                        <label for="quantity"
                                            class="block text-sm font-medium text-gray-700">Cantidad</label>
                                        <input type="number" name="quantity" id="quantity" min="1"
                                            max="<?php echo e($product->stock); ?>" value="1"
                                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                    </div>

                                    <button type="submit"
                                        class="w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                                        <?php echo e($product->stock < 1 ? 'disabled' : ''); ?>>
                                        <?php echo e($product->stock < 1 ? 'Sin stock' : 'Agregar al carrito'); ?>

                                    </button>
                                </form>
                            <?php else: ?>
                                <div class="text-center py-4">
                                    <a href="<?php echo e(route('login')); ?>" class="text-blue-500 hover:text-blue-700">
                                        Inicia sesión para comprar
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH F:\xampp\htdocs\laravel\ecomer-web\resources\views/products/show.blade.php ENDPATH**/ ?>