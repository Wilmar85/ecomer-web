<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['brands']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['brands']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div class="max-w-7xl mx-auto py-12 px-4">
    <h2 class="text-2xl font-bold mb-8 text-center">Nuestras Marcas</h2>
    <div x-data="{
            scroll: null,
            interval: null,
            startScrolling() {
                this.interval = setInterval(() => {
                    this.scroll.scrollLeft += 1;
                    // Reinicia el scroll para efecto infinito
                    if (this.scroll.scrollLeft >= this.scroll.scrollWidth / 2) {
                        this.scroll.scrollLeft = 0;
                    }
                }, 15);
            },
            stopScrolling() {
                clearInterval(this.interval);
            }
        }"
        x-init="scroll = $refs.slider; startScrolling()"
        @mouseenter="stopScrolling()" @mouseleave="startScrolling()"
        class="relative overflow-hidden">
        <div x-ref="slider" class="flex gap-8 items-center py-4 whitespace-nowrap overflow-x-auto scrollbar-hide" style="scroll-behavior: auto; scrollbar-width: none; -ms-overflow-style: none;">
    <style>
        [x-ref=slider]::-webkit-scrollbar {
            display: none;
        }
    </style>
            <?php $__currentLoopData = array_merge($brands, $brands); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex flex-col items-center min-w-[96px]">
    <div class="w-20 h-20 flex items-center justify-center rounded-full bg-white shadow-md overflow-hidden mb-2">
        <img src="<?php echo e(asset('images/brands/' . strtolower(str_replace(' ', '', $brand)) . '.png')); ?>" alt="Logo <?php echo e($brand); ?>" class="w-full h-full object-cover rounded-full aspect-square grayscale hover:grayscale-0 transition duration-300">
    </div>
    <span class="text-sm font-semibold text-gray-700 text-center"><?php echo e($brand); ?></span>
</div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH F:\xampp\htdocs\laravel\ecomer-web\resources\views/components/brand-section.blade.php ENDPATH**/ ?>