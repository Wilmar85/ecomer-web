<img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo" <?php echo e($attributes); ?>>

<?php /**PATH F:\xampp\htdocs\laravel\ecomer-web\resources\views/components/application-logo.blade.php ENDPATH**/ ?>