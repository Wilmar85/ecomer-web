<?php $__env->startSection('title', 'Marcas de Clientes'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="my-12"></div>
    <?php if (isset($component)) { $__componentOriginal128632dfb26b2750bd60af68653f82b1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal128632dfb26b2750bd60af68653f82b1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.brand-section','data' => ['brands' => [
        'MERCURY', 'TITANIUM', 'ZAFIRO', 'ILUMAX', 'ECOLITE', 'EXCELITE', 'INTERLED', 'DEXON', 'BRIOLIGH', 'ROYAL', 'LUMEK',
        'TITANIUM', 'DIXTON', 'BAYTER', 'SPARKLED', 'KARLUX', 'FELGOLUX', 'NEW LIGHT', 'DIGITAL LIGHT', 'SICOLUX', 'ACRILED', 'MARWA'
    ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('brand-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['brands' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
        'MERCURY', 'TITANIUM', 'ZAFIRO', 'ILUMAX', 'ECOLITE', 'EXCELITE', 'INTERLED', 'DEXON', 'BRIOLIGH', 'ROYAL', 'LUMEK',
        'TITANIUM', 'DIXTON', 'BAYTER', 'SPARKLED', 'KARLUX', 'FELGOLUX', 'NEW LIGHT', 'DIGITAL LIGHT', 'SICOLUX', 'ACRILED', 'MARWA'
    ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal128632dfb26b2750bd60af68653f82b1)): ?>
<?php $attributes = $__attributesOriginal128632dfb26b2750bd60af68653f82b1; ?>
<?php unset($__attributesOriginal128632dfb26b2750bd60af68653f82b1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal128632dfb26b2750bd60af68653f82b1)): ?>
<?php $component = $__componentOriginal128632dfb26b2750bd60af68653f82b1; ?>
<?php unset($__componentOriginal128632dfb26b2750bd60af68653f82b1); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel\ecomer-web\resources\views/brands/index.blade.php ENDPATH**/ ?>