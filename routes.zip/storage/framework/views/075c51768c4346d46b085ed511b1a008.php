<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Tienda')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="flex flex-col md:flex-row gap-8">
                <!-- Sidebar de Filtros -->
                <aside class="md:w-1/4 w-full bg-white rounded-lg shadow-md p-6 mb-8 md:mb-0 md:sticky md:top-8">
                    <h2 class="text-xl font-bold text-gray-700 mb-4">Filtrar productos</h2>
                    <form action="<?php echo e(route('shop.index')); ?>" method="GET" class="space-y-6">
                        <!-- Búsqueda por nombre -->
                        <div>
                            <label for="search" class="block text-sm font-medium text-gray-700 mb-1">Buscar por nombre</label>
                            <input type="text" name="search" id="search" value="<?php echo e(request('search')); ?>"
                                class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                                placeholder="Nombre del producto...">
                        </div>
                        <!-- Filtro por categoría -->
                        <div>
                            <label for="category" class="block text-sm font-medium text-gray-700 mb-1">Categoría</label>
                            <select name="category" id="category"
                                class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                                <option value="">Todas las categorías</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php echo e(request('category') == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <!-- Filtro por marca -->
                        <div>
                            <label for="brand" class="block text-sm font-medium text-gray-700 mb-1">Marca</label>
                            <select name="brand" id="brand" class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                                <option value="">Todas las marcas</option>
                                <?php if(isset($brands)): ?>
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($brand->id); ?>" <?php echo e(request('brand') == $brand->id ? 'selected' : ''); ?>><?php echo e($brand->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <!-- Rango de precio predefinido -->
                        <div>
                            <label for="price_range" class="block text-sm font-medium text-gray-700 mb-1">Rango de precio rápido</label>
                            <select name="price_range" id="price_range" class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                                <option value="">Todos</option>
                                <option value="0-100" <?php echo e(request('price_range') == '0-100' ? 'selected' : ''); ?>>$0 - $100</option>
                                <option value="100-250" <?php echo e(request('price_range') == '100-250' ? 'selected' : ''); ?>>$100 - $250</option>
                                <option value="250-500" <?php echo e(request('price_range') == '250-500' ? 'selected' : ''); ?>>$250 - $500</option>
                                <option value="500-1000" <?php echo e(request('price_range') == '500-1000' ? 'selected' : ''); ?>>$500 - $1000</option>
                                <option value="1000-999999" <?php echo e(request('price_range') == '1000-999999' ? 'selected' : ''); ?>>$1000+</option>
                            </select>
                        </div>
                        <!-- Rango de precio personalizado -->
                        <div class="flex gap-2 mt-2">
                            <div class="flex-1">
                                <label for="price_min" class="block text-sm font-medium text-gray-700 mb-1">Precio mínimo</label>
                                <input type="number" name="price_min" id="price_min" value="<?php echo e(request('price_min')); ?>"
                                    class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                                    placeholder="0">
                            </div>
                            <div class="flex-1">
                                <label for="price_max" class="block text-sm font-medium text-gray-700 mb-1">Precio máximo</label>
                                <input type="number" name="price_max" id="price_max" value="<?php echo e(request('price_max')); ?>"
                                    class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                                    placeholder="1000">
                            </div>
                        </div>
                        <!-- Botón de filtrar -->
                        <button type="submit"
                            class="w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition">Filtrar</button>
                    </form>
                </aside>
                <!-- Main: productos -->
                <main class="md:w-3/4 flex-1 md:pl-6 border-t md:border-t-0 md:border-l border-gray-200">
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6">
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php if (isset($component)) { $__componentOriginalecfc721726b8b5798826c96d529d8b59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalecfc721726b8b5798826c96d529d8b59 = $attributes; } ?>
<?php $component = App\View\Components\ProductCard::resolve(['product' => $product] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ProductCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $attributes = $__attributesOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__attributesOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $component = $__componentOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__componentOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-span-full text-center py-12">
                                <p class="text-gray-500 text-lg">No se encontraron productos que coincidan con los filtros seleccionados.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <!-- Paginación -->
                    <?php if($products->hasPages()): ?>
                        <div class="mt-6">
                            <?php echo e($products->links()); ?>

                        </div>
                    <?php endif; ?>
                </main>
            </div>
        </div>
    </div>
<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const priceRange = document.getElementById('price_range');
    const priceMin = document.getElementById('price_min');
    const priceMax = document.getElementById('price_max');
    if (priceRange && priceMin && priceMax) {
        priceRange.addEventListener('change', function () {
            if (this.value) {
                const [min, max] = this.value.split('-');
                priceMin.value = min;
                priceMax.value = max;
            } else {
                priceMin.value = '';
                priceMax.value = '';
            }
        });
    }
});
</script>
<?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH F:\xampp\htdocs\laravel\ecomer-web\resources\views/shop/index.blade.php ENDPATH**/ ?>